import java.util.Scanner;



public class Atividade2 {
    
    public static void main(String[] args) {
        int valor1;
        int valor2;
        Scanner ler;
        ler = new Scanner(System.in);
        
        System.out.print("Digite o primeiro numero: ");
        valor1 = ler.nextInt();
        
        System.out.print("Digite o segundo numero: ");
        valor2 = ler.nextInt();
        
        System.out.println("A soma desses numeros e " + (valor1 + valor2) );
        System.out.println("A diferenca desses numeros e " + (valor1 - valor2) );
        System.out.println("O produto desses numeros e " + (valor1 * valor2));
        System.out.println("A razão desses numeros e " + (valor1 / valor2));
    }
}