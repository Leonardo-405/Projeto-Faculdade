/*
 * 8. Construa um algoritmo que calcule qual é o maior número entre duas
variáveis inteiras.
 */
package atividade14;

import java.util.Scanner;


public class Atividade14 {

    public static void main(String[] args) {
        
        int a;
        int b;
        Scanner input;
        input = new Scanner (System.in);
        
        System.out.println("Digite o primeiro número: ");
        a = input.nextInt();
        
        System.out.println("Digite o segundo número: ");
        b = input.nextInt();
        
        if (a > b){
            System.out.println( a + " é maior que " + b);
        }else
            System.out.println( a + " é menor que " + b);
        
        
    }
    
}
