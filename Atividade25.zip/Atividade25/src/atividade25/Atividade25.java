/*
 * 9) Escreva um algoritmo que leia 20 números do usuário e exiba quantos números são pares e quantos
são ímpares.
 */
package atividade25;

import java.util.Scanner;

public class Atividade25 {
    
    public static void main(String[] args) {
        int numero;
        int pares = 0;
        Scanner ler;
        ler = new Scanner (System.in);
        
        for (int i = 0; i <= 5; i++){
            System.out.print("Digite um número: ");
            numero = ler.nextInt();
            numero = numero % 2;
            if (numero == 0){
                pares = pares + 1;
            }
  
        }
        System.out.println("São " + pares + " números pares.");
    }
    
}
