//Construa um algoritiomo que diga quantos dias voce viveu.
package javaapplication42;
import java.util.Scanner;

public class JavaApplication42 {
    public static void main(String[] args) {
        int idade, dias;
        Scanner ler;
        
        ler = new Scanner (System.in);
        
        System.out.print("Digite sua idade: ");
        idade = ler.nextInt();
        dias = idade * 365;
        System.out.println("Você já viveu " + dias + "dias.");
    }
    
}
