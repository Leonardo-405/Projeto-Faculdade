/*
 * 6. Construa um algoritmo que calcule se um Valor é par ou ímpar
 */
package atividade12;

import java.util.Scanner;

public class Atividade12 {

    public static void main(String[] args) {
        int numero;
        Scanner input;
        input = new Scanner (System.in);
        
        System.out.print("Digite um número: ");
        numero = input.nextInt();
        
        if (numero % 2 == 0){
            System.out.print("Esse número é par." );
        }else
            System.out.println("Esse número é ímpar.");
      
    }
    
}
