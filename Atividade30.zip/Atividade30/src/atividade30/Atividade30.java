/*
 * 14) Escreva um programa para imprimir a série de Fibonacci até a centésima posição:
Exemplo: 0 1 1 2 3 5 8 13 24 ....
 */
package atividade30;

public class Atividade30 {

    public static void main(String[] args) {
        int termo1 = 0;
        int termo2 = 1;
        int fibo;
        
        for (int i = 0; i < 100; i++){
            System.out.print(termo1 + " ");
            fibo = termo1 + termo2;
            termo1 = termo2;
            termo2 = fibo;
        }    
    }
}
    
