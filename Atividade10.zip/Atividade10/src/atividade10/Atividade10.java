/*
 * 4. Construa um algoritmo que calcule o antecessor e sucessor de um número qualquer.
 */
package atividade10;

import java.util.Scanner;


public class Atividade10 {

    public static void main(String[] args) {
        int n;
        int a;
        int s;
        
        Scanner ler;
        ler = new Scanner (System.in);
        
        System.out.println("Qual número deseja saber o antecessor e sucessor?");
        n = ler.nextInt();
        a = n - 1;
        s = n + 1;
        
        System.out.println("O antecessor de " + n + " é " + a + " e seu sucessor é " + s + ".");
                
        
    }
    
}
