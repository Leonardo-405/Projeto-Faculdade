//Faça um algoritmo que leia 20 números e, ao final, escreva quantos estão entre 0 e 100
package for1;
import java.util.Scanner;
public class For1 {
    public static void main(String[] args) {
        int contagem = 0;
        int numero1;
        Scanner ler;
        ler = new Scanner (System.in);
        for (int i = 1; i <= 5; i++){
            System.out.print(i + "- Digite um número: ");
            numero1 = ler.nextInt();
            if (numero1 > 1 && numero1 < 100){
                contagem += 1;
            }

        }
        System.out.println("A quantidade números entre 1 e 100 são " + contagem +".");
    }
    
}
