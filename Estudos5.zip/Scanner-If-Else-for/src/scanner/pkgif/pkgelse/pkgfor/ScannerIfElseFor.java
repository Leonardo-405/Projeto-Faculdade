//As organizações CSM resolveram dar um aumento de salário a 5 dos seus colaboradores e lhe contrataram
//para desenvolver o programa que calculará os reajustes.  

// a. Faça um programa que recebe o salário de um colaborador e o reajuste segundo o seguinte critério, 
// baseado no salário atual;
// b. Salários até R$ 280,00 (incluindo): aumento de 20%;
// c. Salários entre R$ 280,00 e R$700,00: aumento de 15%;
// d. Salários entre R$ 700,00 e R$ 1500,00: aumento de 10%;
// e. Salários de R$ 1500,00 em diante: aumento de 5%
package scanner.pkgif.pkgelse.pkgfor;
import java.util.Scanner;
public class ScannerIfElseFor {
    public static void main(String[] args) {
       double salario, reajuste = 0, porcentagem;
       String nome;
       Scanner ler;
       ler = new Scanner (System.in);
       for (int i = 1; i <= 5; i++){
           System.out.println("Digite o nome do funcionário: ");
           nome = ler.next();
           
           System.out.print("Digite o salário que deverá ser reajustado: ");
           salario = ler.nextInt();
            if (salario <= 280){
                porcentagem = (salario * 20) / 100;
                reajuste = salario + porcentagem;
            }
            if (salario > 280 && salario <= 700){
                porcentagem = (salario * 15) / 100;
                reajuste = salario + porcentagem;
            }
            if (salario > 700 && salario <= 1500){
                porcentagem = (salario * 10) / 100;
                reajuste = salario + porcentagem;
            }
            if (salario > 1500){
                porcentagem = (salario * 5) / 100;
                reajuste = salario + porcentagem;
            }
       System.out.println("O salário de " + nome + " com o reajuste será de R$ " + reajuste);
       System.out.println(" ");
    }
    }
}   
    
