/*
 * 10. Construa um algoritmo que calcule uma Equação de 2 grau.
 */
package atividade16;

import java.util.Scanner;

public class Atividade16 {

    public static void main(String[] args) {
        
      
        double x;
        double resultado;
        Scanner input;
        input = new Scanner (System.in);
        
        System.out.println("Qual o valor de x nessa equação x^2 + 3 . x + 2?");
        x = input.nextInt();
       
        
        resultado = Math.pow(x, 2) + 3 * x + 2;
        System.out.println("O resultado dessa equação de 2 grau: " + resultado);
    }
    
}
