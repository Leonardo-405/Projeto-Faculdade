package atividade4;

import java.util.Scanner;

public class Atividade4 {

    public static void main(String[] args) {
        float nota1;
        float nota2;
        float nota3;
        float nota4;
        float media;
        
        Scanner ler;
        ler = new Scanner(System.in);
        
        System.out.print("Digite sua primeira nota: ");
        nota1 = ler.nextFloat();
        System.out.print("Digite sua segunda nota: ");
        nota2 = ler.nextFloat();
        System.out.print("Digite sua terceira nota: ");
        nota3 = ler.nextFloat();
        System.out.print("Digite sua quarta nota: ");
        nota4 = ler.nextFloat();
        
        media = (nota1 + nota2 + nota3 + nota4)/4;
        
        System.out.println("Sua media: " + media);
        
                
    }
    
}
