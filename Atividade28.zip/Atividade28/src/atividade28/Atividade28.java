/*
 * 12) Escreva um programa que leia 10 números e ao final ele deverá exibir quantos positivos, negativos e
zeros foram digitados.
 */
package atividade28;

import java.util.Scanner;

public class Atividade28 {

    public static void main(String[] args) {
        int numeros;
        int positivos = 0;
        int negativos = 0;
        Scanner ler;
        ler = new Scanner (System.in);
        
        for (int i = 0; i < 10; i++) {
            System.out.print("Digite um número: ");
            numeros = ler.nextInt();
                
                if(numeros >= 1){
                    positivos = positivos + 1;
                } else {
                    negativos = negativos + 1;
                }
            
        }
        System.out.println("Números positivos digitados: " + positivos);
        System.out.println("Números negativos e zeros digitados: " + negativos);
    }
    
}

