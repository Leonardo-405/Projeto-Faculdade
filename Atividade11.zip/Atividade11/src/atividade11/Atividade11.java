/*
 * 5. Construa um algoritmo que exemplifique 5 operações aritméticas.
 */
package atividade11;

import java.util.Scanner;

public class Atividade11 {

    public static void main(String[] args) {
        int n1;
        int n2;
        int soma;
        int sub;
        double div;
        double mult;
        double poten;
        Scanner ler;
        ler = new Scanner (System.in);
        
        System.out.print("Digite o primeiro número: ");
        n1 = ler.nextInt();
        
        System.out.print("Digite o segundo: ");
        n2 = ler.nextInt();
        
        soma = n1 + n2;
        sub = n1 - n2;
        div = n1 / n2;
        mult = n1 * n2;
        poten = Math.pow(n1,n2);
        
        System.out.println("Soma " + soma);
        System.out.println("Subtração " + sub);
        System.out.println("Divisão " + div);
        System.out.println("Multiplicação " + mult);
        System.out.println("Potenciação " + poten);
         
    }
    
}
