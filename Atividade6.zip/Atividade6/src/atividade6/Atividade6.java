
package atividade6;

import java.util.Scanner;

public class Atividade6 {

    public static void main(String[] args) {
        
        int cavalos;
        int ferraduras;
        
        Scanner ler;
        ler = new Scanner(System.in);
        
        System.out.println("Quantos cavalos voce tem?");
        cavalos = ler.nextInt();
        
        ferraduras = 4 * cavalos;
        
        System.out.print("Voce vai precissar de " + ferraduras);
        System.out.print(" ferraduras.");
        
     
    }
    
}
