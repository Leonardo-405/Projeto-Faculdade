/*
 * 11) Escreva um programa que solicite ao usuário que insira um número inteiro positivo. Em seguida, deve
imprimir a tabuada de multiplicação completa desse mesmo número
 */
package atividade27;

import java.util.Scanner;

public class Atividade27 {

    public static void main(String[] args) {
        
        int numero;
        int resultado;
        Scanner ler;
        ler = new Scanner (System .in);
        
        System.out.println("Qual tabuada você deseja?");
        numero = ler.nextInt();
        
        for (int i = 0; i <= 10; i++){
            resultado = numero * i;
            
            System.out.println(numero + " x " + i + " = " + resultado);
            
        }
        
        
    }
    
}
