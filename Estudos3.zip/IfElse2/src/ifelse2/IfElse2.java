//Construa um algoritmo que calcule qual é o maior número entre duas
//variáveis inteiras.
package ifelse2;
import java.util.Scanner;
public class IfElse2 {
    public static void main(String[] args) {
        int numero1, numero2;
        Scanner ler;
        ler = new Scanner (System.in);
        System.out.print("Digite o primeiro número: ");
        numero1 = ler.nextInt();
        System.out.print("Digite o segundo número: ");
        numero2 = ler.nextInt();
        if (numero1 > numero2){
           System.out.println(numero1 + " é maior que " + numero2 +".");
        }else{
            System.out.println(numero1 + " é menor que " + numero2 +".");
        }
    }
    
}
