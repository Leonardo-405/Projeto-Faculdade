/*
 * Construa um algoritmo que calcule o dobro de um número qualquer.
 */
package atividade8;

import java.util.Scanner;

public class Atividade8 {

    public static void main(String[] args) {
        float a;
        float resultado;
        Scanner ler;
        ler = new Scanner(System.in);
        
        System.out.print("Digite um numero: ");
        a = ler.nextFloat();
        
        resultado =  a * 2;
        
        System.out.println ("O dobro de " + a + " e " + resultado);
                
        
        
    }
    
}
