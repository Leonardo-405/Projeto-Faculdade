//4) Leia o nome e um número qualquer do usuário. Escreva seu nome na tela a mesma quantidade de
//vezes do número


import java.util.Scanner;

public class Atividade20 {

    public static void main(String[] args) {
        String nome;
        int numero;
        Scanner ler;
        ler = new Scanner ( System.in);
        
         System.out.print("Digite seu nome: ");
         nome = ler.nextLine();
         
         System.out.print("Digite o numero de repetições: ");
         numero = ler.nextInt();
         
         for (int i = 1; i <= numero; i++){
             System.out.println( i + ":" + nome + ";" );
         }
                 
    }
    
}
