/*
 * Escreva um algoritmo que calcule a soma dos números de 1 a 15.
 */
package atividade18;

public class Atividade18 {

    public static void main(String[] args) {
       
        int soma = 0;
        int valor;
        
       for(int i = 0; i <= 15; i++){
           soma = soma + i;
           valor = soma - i;
           System.out.println("Soma dos números: " + valor + " + " + i + " = " + soma);
       }
}
}