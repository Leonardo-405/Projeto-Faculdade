/*
 * 6) Leia a idade de 20 pessoas e exiba a soma das idades
 */
package atividade22;

import java.util.Scanner;

public class Atividade22 {

    public static void main(String[] args) {
        int idade;
        int soma = 0;
        Scanner ler;
        ler = new Scanner (System.in);
        
        for (int i = 1; i <= 20; i++ ){
            System.out.print("Digite a idade: ");
            idade = ler.nextInt();
            soma = soma + idade;
        }
        System.out.println("A soma dessas idades: " + soma );
    }
    
}
