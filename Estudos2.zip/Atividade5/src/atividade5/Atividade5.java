package atividade5;

import java.util.Scanner;

public class Atividade5 {
    
    public static void main(String[] args) {
         String nome;
         int idade;
         int dias;
         
         Scanner ler;
         ler = new Scanner(System.in);
         
         System.out.print("Digite seu nome: ");
         nome = ler.nextLine();
         System.out.print("Digite sua idade: ");
         idade = ler.nextInt();
         
         dias = 365 * idade;
         
         System.out.print("Seu nome é " + nome);
         System.out.print(" e ja viveu " + dias);
                
    }
    
}
