/*
 * Construa um algoritmo que calcule a área de um retângulo.
 */
package atividade9;

import java.util.Scanner;


public class Atividade9 {

  
    public static void main(String[] args) {
        int base;
        int altura;
        int area;
        
        Scanner ler;
        
        ler = new Scanner(System.in);
        
        System.out.print("Digite a base do retângulo: ");
        base = ler.nextInt();
        
        System.out.print("Agora digite sua altura: ");
        altura = ler.nextInt();
        
        area = altura * base;
        
        System.out.println("A área desse retângulo é " + area);
        
                
       
    }
    
}
