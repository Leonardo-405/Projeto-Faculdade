/*
 * 7) Leia a idade de 20 pessoas e exiba a média das idades
 */
package atividade23;

import java.util.Scanner;

public class Atividade23 {

    public static void main(String[] args) {
       double idade;
       double soma = 0;
       double media;
       Scanner ler;
       ler = new Scanner (System.in);
       
       for (int i = 0; i < 20; i++) {
           System.out.print("Digite a idade: ");
           idade = ler.nextInt();
           soma = soma + idade;
       }
       media = soma / 20;
       System.out.println("A média de idade é: " + media);
    }
    
}
