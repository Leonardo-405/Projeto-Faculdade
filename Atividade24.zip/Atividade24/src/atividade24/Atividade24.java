/*
 * 8) Leia a idade de 20 pessoas e exiba quantas pessoas são maiores de idade.
 */
package atividade24;

import java.util.Scanner;

public class Atividade24 {

    public static void main(String[] args) {
       int idade;
       int maiores = 0;
       Scanner ler;
       ler = new Scanner (System.in);
       
       for (int i = 0; i <= 2; i++ ){
           System.out.print("Digite a idade: ");
           idade = ler.nextInt();
           if (idade >= 18) {
               maiores = maiores ++;
           }
           
       }
       System.out.println("São maiores de idade: " + maiores);
    }
    
}
