/*
 * 3) Leia o nome do usuário e escreva o nome dele na tela 10 vezes.
 */
package atividade19;

import java.util.Scanner;

public class Atividade19 {

    public static void main(String[] args) {
       String nome;
       Scanner ler;
       ler = new Scanner (System.in);
       
       System.out.print("Digite seu nome: ");
       nome = ler.nextLine(); // Next Line para ler o texto completo.
       
       for ( int i = 1 ; i <= 10; i++ ) {
           System.out.println(nome + " " + i);
       }
       
    }
    
}
