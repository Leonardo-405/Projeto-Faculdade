/**
 * Construa um algoritmo que troque o valor de duas variáveis 
 *(mostrar ante e depois os valores) sem usar cálculo matemático.
 */


package atividade7;

import java.util.Scanner;

public class Atividade7 {

    public static void main(String[] args) {
        
        int a;
        int b;
        int temp;
        Scanner ler;
        ler = new Scanner (System.in);
        
        System.out.println("Digite um número: ");
        a = ler.nextInt();
        
        System.out.println("Digite outro: ");
        b = ler.nextInt();
        
                
        System.out.println(a +","+ b);
        
        temp = a;
        a = b;
        b = temp;
        
        System.out.println(a +","+ b);
                
    
    }
    
}
