/*
 * 13) Escreva um programa que leia 10 números, ao final o programa deverá exibir o maior e o menor
número digitado pelo usuário.
 */
package atividade29;

import java.util.Scanner;

public class Atividade29 {

    public static void main(String[] args) {
        int numero;
        int menor = 0;
        int maior = 0;
        Scanner ler;
        ler = new Scanner (System.in);
        
        for (int i = 0; i < 10; i++){
            System.out.print("Digite um número: ");
            numero = ler.nextInt();
                if (i == 0) {
                    menor = numero;
                    maior = numero;
                }
                if (numero > maior){
                    maior = numero;
                }
                if (numero < menor){
                    menor = numero;
                }

        }
        
        System.out.println("o menor: " + menor );
        System.out.println("o maior: " + maior);
    }
    
}
