
package atividade.pkg3;

import java.util.Scanner;


public class Atividade3 {
    
    public static void main(String[] args) {
        String nome;
        String endereço;
        String telefone;
        String trabalho;
        
        Scanner ler;
        ler = new Scanner(System.in);
      
         System.out.print("Digite seu nome: ");
         nome = ler.nextLine();
         
         System.out.print("Digite seu endereço: ");
         endereço = ler.nextLine();
         
         System.out.print("Digite seu telefone: ");
         telefone = ler.nextLine();
         
         System.out.print("Digite qual o seu trabalho: ");
         trabalho = ler.nextLine();
         
         System.out.println("Seu nome: " + nome);
         System.out.println("Seu endereço: " + endereço);
         System.out.println("Seu telefone: " + telefone);
         System.out.println("Seu trabalho: " + trabalho);
                 
    }
    
}
