package atividade1;

import java.util.Scanner;

public class Atividade1 {

    
    public static void main(String[] args) {
        int valor1;
        Scanner ler;
        
        ler = new Scanner(System.in);
        
        System.out.print("Digite um número: ");
        valor1 = ler.nextInt();
        
        System.out.print("Você digitou " + valor1);