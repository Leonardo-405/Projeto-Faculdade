/*
 * 10) Faça um algoritmo que leia 20 números e, ao final, escreva quantos estão entre 0 e 100
 */
package atividade26;

import java.util.Scanner;

public class Atividade26 {

    public static void main(String[] args) {
        int numero;
        int entre = 0;
        Scanner ler;
        ler = new Scanner (System.in);
        
        for(int i = 0; i < 5; i++){
            System.out.print("Digite o número: ");
            numero = ler.nextInt();
            if( numero > 0 && numero < 100) {
                entre = entre + 1;
                
            }
        }
      System.out.println("A quantidade de números entre 0 e 100 são " + entre + ".");
    }
    
}
