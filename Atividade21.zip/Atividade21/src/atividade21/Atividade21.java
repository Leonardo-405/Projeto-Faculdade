/*
 * 5) Escreva um algoritmo que leia 10 números do usuário e calcule a soma desses números.
 */
package atividade21;
import java.util.Scanner;

public class Atividade21 {

    public static void main(String[] args) {
        int numero;
        int soma = 0;
        Scanner ler;
        ler = new Scanner (System.in);
        
        for (int i = 1; i <= 10; i++){
            System.out.print("Digite um número: ");
            numero = ler.nextInt();
            soma = soma + numero;
            
        }
        System.out.println("A soma desses números: " + soma);
        
    }
    
}
