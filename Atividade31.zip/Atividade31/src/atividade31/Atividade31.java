/*
 * 15) Escreva um programa que leia um número do usuário, após a leitura o programa deverá realizar a
soma abaixo indicada até que o número digitado pelo usuário seja alcançado começando a partir de 1.
Exemplo: 1 + 1/2 + 1/3 + 1/4 + 1/5 +............1/n (n será o número digitado pelo usuário).
 */
package atividade31;

import java.util.Scanner;

public class Atividade31 {

    public static void main(String[] args) {
        double numero;
        double resultado = 0.0;
    
        
        Scanner ler;
        ler = new Scanner (System.in);
        
        System.out.println("Digite um número: ");
        numero = ler.nextInt();
        
        for (int i = 1; i <= numero; i++){
            resultado += (1.0 / i);
                if (i > 1){
                    System.out.print(" + ");
                    
                }
            System.out.print(" 1/" + i); 
  
        }
        System.out.println(" = " + resultado);
    }
    
}
