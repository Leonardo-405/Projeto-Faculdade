/*
 * Construa um algoritmo que calcule se um Valor é positivo ou negativo
 */
package atividade13;

import java.util.Scanner;

public class Atividade13 {
    
    public static void main(String[] args) {
        int numero;
        Scanner input;
        input = new Scanner(System.in);
        
        System.out.print("Digite um número: ");
        numero = input.nextInt();
        
        if (numero >= 0){
            System.out.println("Esse número é positivo.");
        }else
            System.out.println("Esse número é negativo.");
        
        
    }
    
}
