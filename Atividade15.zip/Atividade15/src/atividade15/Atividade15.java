/*
 * 9. Construa um algoritmo que converta Celsius/Fahrenheit
 */
package atividade15;

import java.util.Scanner;

public class Atividade15 {

    public static void main(String[] args) {
       int celsius;
       int fahrenheit;
       Scanner input;
       input = new Scanner (System.in);
       
        System.out.println("Quantos graus Celsius você deseja que seja convertido em Fahrenheit?");
        celsius = input.nextInt();
        
        fahrenheit = celsius * 9/5 + 2;
        
        System.out.println(celsius + " graus Celsius em Fahrenheit é " +  fahrenheit);
        
        
        
        
       
       
       
    }
    
}
